# TC sources

Each TC below was generated from one flow of the shipped test plan (`EVPN_test_plan_with_RFCs.xlsx`). The flows are the three chosen on 2026-07-12: FLOW-010, FLOW-030 and FLOW-031.

For each TC: the flow's base case as the plan states it, then the steps the generator made of it.

## Input: Exaware's automated flow, 2026-07-12

TC02 and TC03 follow this flow step by step. Quoted verbatim.

```
From: Eyal Ozeri (Exaware), 2026-07-12, "RE: AI Automation -Status Update". Verbatim.

Per my comment from Thursday, these are the flows we can address

  * Flow-010, Vlan-based EVPN bringup.
  * Flow-030, Flow-031 – Type-2 and Type-3 advertisement.
  * Both use Ixia for local traffic.

Required modifications to the TP to support a single DuT+ 3 Ixia ports :

  * Flow-010 is a pre-requisite for Flows 030 and 031.
  * Flow 030/031
     * Configuring 3 local ACs.

Detailed Automated flow will be:

  * 3 Ixia traffic items, AC2 and AC3 having the same MAC addresses.
     * AC1 to AC2
     * AC2 to AC1
     * AC3 to AC1
  * Establish a service with 3 ACs and EVPN neighbouring PE
  * Verify relevant shows
     * Show evpn global, show evpn mac-address, show bgp l2vpn evpn...
     * Verify type-3 is reported as advertised
  * Send traffic from AC1 to AC2
     * Verify traffic flooding to AC2 and AC3 (Using Dut counters and Ixia counters)
     * Verify AC1 src MACs learnt from correct interface
     * Verify AC1 x src Type-2 are advertised
  * Send traffic from AC2 to AC1
     * Verify flooding ceases to AC3
     * Verify AC1 src MACs are in tact
     * Verify AC2 src MACs learnt from correct interface
     * Verify AC2 src MACs Type-2 are also advertised
  * Stop AC2 to AC1 traffic
     * Verify AC1 to AC2 traffic still flows to AC2
  * Start traffic from AC3 to AC1
     * Verify AC2 MAC addresses shifted to AC3
     * Verify no type-2 message was triggered
     * Verify AC1 to AC2 traffic flows to AC3.
  * Stop traffic AC3 to AC1
     * Wait for aging time to expire
     * AC1 to AC2 traffic floods to AC2 and AC3
     * AC2 MACs are removed from the evpn mac-table
     * AC2 MACs type-2 msgs are withdrawn from the BGP table.
```

## TC01_EvpnVlanBasedBringUp

Source: **FLOW-010 - Single-homed VLAN-Based EVPN bring-up**
(plan section: FEATURE FUNCTIONALITY). Generated as: EVPN VLAN-based bring-up with three local ACs.

### Plan rows (base case)

| # | Action | Expectation | Monitor |
|---|---|---|---|
| 1 | CE attached single-homed to PE1 access port; access port carries one VLAN | Prerequisite established |  |
| 2 | On PE1: `evpn evi-1 service-type vlan-based` under `configuration l2-services`; set `auto-discovery enable`, `import-rt 65000:1`/`export-rt 65000:1`; bind the access AC with `interface agg-eth-1 evpn evi-1`; commit | EVI up within ≤ 10 s of commit; | show evpn evi evi-1, show evpn evi, show evpn mac address-table, show running-config / include evpn |
| 3 | From IXIA, send 1 Gbps known-unicast (then unknown-unicast) frames PE1→PE2 and PE2→PE1 for ≥ 60 s | Pass: EVI up within ≤ 10 s of commit Pass: both Type 2 and Type 3 routes installed and used (unicast on Type 2, BUM on the Type 3 IMET) Pass: bidirectional unicast forwarded Pass: MAC table reflects learned MACs Pass: ≤ 0 packet drops over the 60 s steady-state window Fail-on: EVI never reaches up state, MAC not learned, frames black-holed, or commit rejected | show evpn evi evi-1, show evpn evi, show evpn mac address-table, show running-config / include evpn |

The plan has 24 more row(s) under this flow for other test categories. They are not automated.

### Generated steps

| # | Step ID | Title | Call |
|---|---|---|---|
| 1 | FLOW-010.S00A | Verify evi-1 does not exist before this test creates it | `evpnUtils.verifyShowLinesAbsent(EvpnCommands.SHOW_EVPN_SUMMARY, testParams.FLOW010_S00A_EVI_ABSENT_LINES);` |
| 2 | FLOW-010.S00B | Verify OSPF adjacency to the tester (29.31.31.31) is Full | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_OSPF_NEIGHBORS, testParams.FLOW010_S00B_OSPF_FULL_LINES);` |
| 3 | FLOW-010.S00C | Verify the LDP session to the tester (29.60.0.2) is Operational | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_LDP_NEIGHBORS, testParams.FLOW010_S00C_LDP_OPERATIONAL_LINES);` |
| 4 | FLOW-010.S00D | Verify the BGP session loopback to loopback (29.30.30.30 - 29.31.31.31) is up | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_BGP_NEIGHBORS, testParams.FLOW010_S00D_BGP_UP_LINES);` |
| 5 | FLOW-010.S01 | Create evi-1 (vlan-based, import-rt and export-rt 65000:1, 3 attachment circuits) in one commit | `evpnUtils.stageConfig(EvpnCommands.CONFIGURE_L2_SERVICES_EVPN_$_SERVICE_TYPE_$.args("evi-1", "vlan-based"));` |
| 6 | FLOW-010.S08 | Verify evi-1 is up and all 3 attachment circuits are bound | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_EVPN_DETAIL, evpnUtils.eviBoundLines("evi-1"));` |
| 7 | FLOW-010.S09 | Verify the EVPN MAC address-table has no learnt MAC yet | `evpnUtils.verifyShowLinesAbsent(EvpnCommands.SHOW_EVPN_MAC_ADDRESS_TABLE_NAME_$.args("evi-1"), testParams.FLOW010_S09_MAC_TABLE_EMPTY_LINES);` |
| 8 | FLOW-010.S10 | Verify the DUT originates the Type-3 IMET route for evi-1 (advertised to the tester 29.31.31.31) | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_BGP_L2VPN_EVPN_NEIGHBORS_ADVERTISED_ROUTES_$_DETAIL.args("29.31.31.31"), testParams.FLOW010_S10_TYPE3_ADVERTISED_LINES);` |
| 9 | FLOW-010.S11 | Verify the BGP session to the tester negotiated L2VPN EVPN (advertised and received) | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_BGP_NEIGHBOR_$_EVPN_CAPABILITY.args("29.31.31.31"), testParams.FLOW010_S11_EVPN_CAPABILITY_LINES);` |

## TC02_EvpnType2MacIpAdvertisement

Source: **FLOW-030 - Route Type 2 MAC/IP advertisement and learning**
(plan section: FEATURE FUNCTIONALITY). Generated as: EVPN Type-2 MAC learning, known-unicast forwarding and local.

### Plan rows (base case)

| # | Action | Expectation | Monitor |
|---|---|---|---|
| 1 | Two-PE EVPN up; CE attached to PE1; clean MAC table | Prerequisite established |  |
| 2 | (1) Send a known-unicast frame from CE-A (behind PE1) to CE-B (behind PE2) in three encodings: MAC-only (no IP), IPv4 host (10.0.0.1 → 10.0.0.2), and IPv6 host (2001:db8::1 → 2001:db8::2); capture the BGP UPDATE on PE↔PE for each. (2) Re-advertise MAC+IP carrying (a) a standard community, (b) a non-reserved extended community, and (c) a reserved community, and once with none. (3) Before CE-B's MAC is learned, send a frame to it and observe BUM flooding; then let PE2 learn CE-B via Type 2 and confirm subsequent frames switch from the BUM/IMET label to the unicast Type-2 label. (4) Move CE-A's MAC from one local AC to another local AC on PE1 and watch the PE↔PE session | Pass: Type 2 encoded per §7.2 for MAC-only, IPv4 and IPv6 Pass: remote install + bidirectional flow for each Pass: communities (incl Pass: reserved) handled cleanly Pass: forwarding switches BUM→unicast on learn Pass: a purely-local interface move triggers no re-advertisement Fail-on: MAC length ≠ 48, IP Address Length field ≠ 0/32/128, missing label, malformed RD/ESI, IPv6 host IP not carried, a community mishandled/corrupted, forwarding stuck on the BUM label after learning, a local interface move spuriously re-advertising the MAC, or remote PE drops the route Type 2 NLRI carries: RD + ESI (zero for single-homed) + Eth-Tag + MAC (length=48) + (optional) IP (0 for MAC-only, 4-byte for IPv4, 16-byte for IPv6 - IP Address Length field reflects which) + MPLS Label1 [+ Label2] per RFC 7432bis §7.2; remote PE installs MAC (+ label) for the MAC-only, v4 and v6 entries; reverse traffic forwards on the learned label Standard and extended communities (including reserved ones) are carried / handled per policy without corrupting the route Once the MAC is learned via Type 2, forwarding switches from the BUM/IMET label to the unicast label A MAC moving between two LOCAL ACs on PE1 updates the local forwarding entry but does NOT emit a new Type 2 advertisement or a MAC-mobility event | show bgp l2vpn evpn, show bgp l2vpn evpn detail, show evpn mac address-table |

The plan has 21 more row(s) under this flow for other test categories. They are not automated.

### Generated steps

| # | Step ID | Title | Call |
|---|---|---|---|
| 1 | FLOW-030.S00V | Verify evi-1 from the bring-up configuration is up with all 3 attachment circuits bound | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_EVPN_DETAIL, evpnUtils.eviBoundLines("evi-1"));` |
| 2 | FLOW-030.S00B | Verify OSPF adjacency to the tester (29.31.31.31) is Full | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_OSPF_NEIGHBORS, testParams.FLOW030_S00B_OSPF_FULL_LINES);` |
| 3 | FLOW-030.S00C | Verify the LDP session to the tester (29.60.0.2) is Operational | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_LDP_NEIGHBORS, testParams.FLOW030_S00C_LDP_OPERATIONAL_LINES);` |
| 4 | FLOW-030.S00D | Verify the BGP session loopback to loopback (29.30.30.30 - 29.31.31.31) is up | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_BGP_NEIGHBORS, testParams.FLOW030_S00D_BGP_UP_LINES);` |
| 5 |  | Load the IXIA traffic items this test drives | `evpnUtils.createTrafficItems();` |
| 6 | FLOW-030.S01 | Clear the EVPN MAC address-table so learning starts clean | `evpnUtils.execAndVerifyAccepted(EvpnCommands.CLEAR_EVPN_MAC_ADDRESS_TABLE_NAME_$.args("evi-1"));` |
| 7 | FLOW-030.S02 | Start traffic AC1 -> AC2 (unicast to 00:00:02:00:00:01, not yet learnt) | `evpnUtils.changeSuspendStatus(false, testParams.TI_AC1_TO_AC2);` |
| 8 | FLOW-030.S03 | Verify unknown unicast from AC1 is flooded to BOTH AC2 and AC3 (rx 2000 = 2 x tx; DUT transmits on both) | `evpnUtils.verifyIxiaStatistics("Verify unknown unicast from AC1 is flooded to BOTH AC2 and AC3 (rx 2000 = 2 x tx; DUT transmits on both)", testParams.FLOW030_S03_UNKNOWN_UNICAST_FLOODED_ROWS);` |
| 9 | FLOW-030.S04 | Verify 00:00:01:00:00:01 is learnt on AC1 (VLAN 1001) | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_EVPN_MAC_ADDRESS_TABLE_NAME_$_SOURCE_$.args("evi-1", evpnUtils.acInterfaceCompact(0)), testParams.FLOW030_S04_AC1_MACS_LEARNT_LINES);` |
| 10 | FLOW-030.S05 | Verify the DUT originates a Type-2 route for 00:00:01:00:00:01 (advertised to the tester 29.31.31.31) | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_BGP_L2VPN_EVPN_NEIGHBORS_ADVERTISED_ROUTES_$_DETAIL.args("29.31.31.31"), testParams.FLOW030_S05_AC1_TYPE2_ADVERTISED_LINES);` |
| 11 | FLOW-030.S06 | Start traffic AC2 -> AC1 (AC2 sources 00:00:02:00:00:01) | `evpnUtils.changeSuspendStatus(false, testParams.TI_AC2_TO_AC1);` |
| 12 | FLOW-030.S07 | Verify AC1 -> AC2 is now KNOWN unicast: rx 1000, out of AC2 only, nothing to AC3 | `evpnUtils.verifyIxiaStatistics("Verify AC1 -> AC2 is now KNOWN unicast: rx 1000, out of AC2 only, nothing to AC3", testParams.FLOW030_S07_KNOWN_UNICAST_ROWS);` |
| 13 | FLOW-030.S09 | Verify 00:00:02:00:00:01 is learnt on AC2 (VLAN 1002) | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_EVPN_MAC_ADDRESS_TABLE_NAME_$_SOURCE_$.args("evi-1", evpnUtils.acInterfaceCompact(1)), testParams.FLOW030_S09_AC2_MACS_LEARNT_LINES);` |
| 14 | FLOW-030.S10 | Verify the DUT originates a Type-2 route for 00:00:02:00:00:01 (advertised to the tester 29.31.31.31) | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_BGP_L2VPN_EVPN_NEIGHBORS_ADVERTISED_ROUTES_$_DETAIL.args("29.31.31.31"), testParams.FLOW030_S10_AC2_TYPE2_ADVERTISED_LINES);` |
| 15 | FLOW-030.S13 | Snapshot the DUT's Type-2 route for 00:00:02:00:00:01 before moving it to AC3 | `routesBefore = evpnUtils.snapshot(EvpnCommands.SHOW_BGP_L2VPN_EVPN_NEIGHBORS_ADVERTISED_ROUTES_$_DETAIL.args("29.31.31.31"));` |
| 16 | FLOW-030.S11 | Stop traffic AC2 -> AC1 | `evpnUtils.changeSuspendStatus(true, testParams.TI_AC2_TO_AC1);` |
| 17 | FLOW-030.S14 | Start traffic AC3 -> AC1 (AC3 sources 00:00:02:00:00:01, the same MAC as AC2: a local MAC move) | `evpnUtils.changeSuspendStatus(false, testParams.TI_AC3_TO_AC1);` |
| 18 | FLOW-030.S15 | Verify 00:00:02:00:00:01 has moved to AC3 (VLAN 1003) | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_EVPN_MAC_ADDRESS_TABLE_NAME_$_SOURCE_$.args("evi-1", evpnUtils.acInterfaceCompact(2)), testParams.FLOW030_S15_MACS_MOVED_TO_AC3_LINES);` |
| 19 | FLOW-030.S16 | Verify the local AC2 -> AC3 move did not re-originate the Type-2 route for 00:00:02:00:00:01 (route unchanged vs the snapshot) | `evpnUtils.verifyOutputUnchanged(routesBefore, EvpnCommands.SHOW_BGP_L2VPN_EVPN_NEIGHBORS_ADVERTISED_ROUTES_$_DETAIL.args("29.31.31.31"), "Verify the local AC2 -> AC3 move did not re-originate the Type-2 route for 00:00:02:00:00:01 (route unchanged vs the snapshot)");` |
| 20 | FLOW-030.S16B | Verify the Type-2 for 00:00:02:00:00:01 still carries MAC Mobility SeqNum=0 after the local move (advertised to the tester 29.31.31.31) | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_BGP_L2VPN_EVPN_NEIGHBORS_ADVERTISED_ROUTES_$_DETAIL.args("29.31.31.31"), testParams.FLOW030_S16B_SEQNUM_UNCHANGED_LINES);` |
| 21 | FLOW-030.S17 | Verify AC1 -> AC2 now follows the MAC: rx 1000, out of AC3 only, nothing to AC2 | `evpnUtils.verifyIxiaStatistics("Verify AC1 -> AC2 now follows the MAC: rx 1000, out of AC3 only, nothing to AC2", testParams.FLOW030_S17_FOLLOWS_MOVE_ROWS);` |

## TC03_EvpnType3ImetFlooding

Source: **FLOW-031 - Route Type 3 IMET + ingress-replication BUM**
(plan section: FEATURE FUNCTIONALITY). Generated as: EVPN MAC aging: Type-2 withdrawal and return to flooding.

### Plan rows (base case)

| # | Action | Expectation | Monitor |
|---|---|---|---|
| 1 | Three-PE EVPN (PE1, PE2, PE3) all in the same EVI; ingress-replication PMSI; a BUM source on access at PE1 | Prerequisite established |  |
| 2 | (1) On EVI join, confirm each PE installs and advertises its own Type 3 IMET route; verify PE1 installs its own and receives + installs PE2's and PE3's, building the ingress-replication flood list. (2) Send a broadcast from PE1's access port; trace replication on PE1→PE2 and PE1→PE3. (3) Send an unknown-unicast from PE1; confirm it is flooded to PE2 and PE3 over the IR list, the destination's MAC is then learned (Type 2), and subsequent frames to it forward unicast without further flooding | Pass: All three PEs advertise + install each other's IMET Pass: one copy per remote PE for BUM Pass: correct PMSI encoding Pass: unknown-unicast transitions from flooded to unicast once the MAC is learned Fail-on: A PE fails to advertise or install an IMET, duplicate replication, missing PMSI Tunnel attribute, wrong tunnel type, BUM delivered to a non-EVI PE, or unknown-unicast keeps flooding after the MAC is learned Each PE's Type 3 NLRI is encoded per §7.3; the PMSI Tunnel attribute encodes the tunnel type (ingress replication), label, and tunnel ID; every PE installs every other PE's IMET; broadcast and unknown-unicast reach each remote PE exactly once (no duplication); after MAC learning, unknown-unicast to that MAC stops flooding and forwards on the unicast label | show bgp l2vpn evpn, show bgp l2vpn evpn detail, show evpn mac address-table |

The plan has 10 more row(s) under this flow for other test categories. They are not automated.

### Generated steps

| # | Step ID | Title | Call |
|---|---|---|---|
| 1 | FLOW-031.S00V | Verify evi-1 from the bring-up configuration is up with all 3 attachment circuits bound | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_EVPN_DETAIL, evpnUtils.eviBoundLines("evi-1"));` |
| 2 | FLOW-031.S00B | Verify OSPF adjacency to the tester (29.31.31.31) is Full | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_OSPF_NEIGHBORS, testParams.FLOW031_S00B_OSPF_FULL_LINES);` |
| 3 | FLOW-031.S00C | Verify the LDP session to the tester (29.60.0.2) is Operational | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_LDP_NEIGHBORS, testParams.FLOW031_S00C_LDP_OPERATIONAL_LINES);` |
| 4 | FLOW-031.S00D | Verify the BGP session loopback to loopback (29.30.30.30 - 29.31.31.31) is up | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_BGP_NEIGHBORS, testParams.FLOW031_S00D_BGP_UP_LINES);` |
| 5 |  | Load the IXIA traffic items this test drives | `evpnUtils.createTrafficItems();` |
| 6 | FLOW-031.S01A | Set mac-aging-time 60 on evi-1 | `evpnUtils.configAndVerifyAccepted(EvpnCommands.CONFIGURE_L2_SERVICES_EVPN_$_MAC_AGING_TIME_$.args("evi-1", "60"));` |
| 7 | FLOW-031.S01P | Start traffic AC1 -> AC2 and AC2 -> AC1 so 00:00:02:00:00:01 is learnt on AC2 | `evpnUtils.changeSuspendStatus(false, testParams.TI_AC1_TO_AC2, testParams.TI_AC2_TO_AC1);` |
| 8 | FLOW-031.S01Q | Verify 00:00:02:00:00:01 is learnt on AC2 before the aging test begins | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_EVPN_MAC_ADDRESS_TABLE_NAME_$_SOURCE_$.args("evi-1", evpnUtils.acInterfaceCompact(1)), testParams.FLOW031_S01Q_MACS_LEARNT_LINES);` |
| 9 | FLOW-031.S01R | Verify AC1 -> AC2 is known unicast while 00:00:02:00:00:01 is learnt: rx 1000, AC2 only | `evpnUtils.verifyIxiaStatistics("Verify AC1 -> AC2 is known unicast while 00:00:02:00:00:01 is learnt: rx 1000, AC2 only", testParams.FLOW031_S01R_KNOWN_UNICAST_ROWS);` |
| 10 | FLOW-031.S01 | Stop traffic AC2 -> AC1, so nothing refreshes its MAC | `evpnUtils.changeSuspendStatus(true, testParams.TI_AC2_TO_AC1);` |
| 11 | FLOW-031.S02 | Wait out the 60 s MAC aging time | `evpnUtils.waitSeconds(testParams.MAC_AGING_TIME_IN_SEC, "Wait out the 60 s MAC aging time");` |
| 12 | FLOW-031.S04 | Verify 00:00:02:00:00:01 has aged out of the EVPN MAC table | `evpnUtils.verifyShowLinesAbsent(EvpnCommands.SHOW_EVPN_MAC_ADDRESS_TABLE_NAME_$.args("evi-1"), testParams.FLOW031_S04_MACS_AGED_OUT_LINES, testParams.AGING_VERIFY_TIMEOUT_IN_MSEC);` |
| 13 | FLOW-031.S05 | Verify the Type-2 route for 00:00:02:00:00:01 is withdrawn (advertised to the tester 29.31.31.31) | `evpnUtils.verifyShowLinesAbsent(EvpnCommands.SHOW_BGP_L2VPN_EVPN_NEIGHBORS_ADVERTISED_ROUTES_$_DETAIL.args("29.31.31.31"), testParams.FLOW031_S05_TYPE2_WITHDRAWN_LINES, testParams.AGING_VERIFY_TIMEOUT_IN_MSEC);` |
| 14 | FLOW-031.S03 | Verify AC1 -> AC2 is flooded again now 00:00:02:00:00:01 is unknown: rx 2000, out of AC2 AND AC3 | `evpnUtils.verifyIxiaStatistics("Verify AC1 -> AC2 is flooded again now 00:00:02:00:00:01 is unknown: rx 2000, out of AC2 AND AC3", testParams.FLOW031_S03_FLOODED_AFTER_AGING_ROWS);` |
| 15 | FLOW-031.S06 | Verify the broadcast domain still lists all 3 circuits as flood targets | `evpnUtils.verifyShowLines(EvpnCommands.SHOW_EVPN_BROADCAST_DOMAINS_NAME_$.args("evi-1"), evpnUtils.eviBoundLines("evi-1"));` |
