# Test plan changes — EVPN_test_plan_with_RFCs.xlsx

Comparing **EVPN_test_plan_with_RFCs_previous.xlsx** → **EVPN_test_plan_with_RFCs.xlsx**.

This respin answers Eyal Ozeri's 2026-07-06/07/08 review batches and the 2026-08-16 mail. The BGP address-family knobs are no longer hand-curated: their grammar, ranges and defaults are now read from Exaware's Command Reference Guide v8.X.0, which corrected every one of the seven previously curated entries and added the missing `weight`. VPLS-only content is scoped out of the EVPN plan. See the covering mail for the one document conflict (`allow-as-in` SAFI applicability) that needs an Exaware ruling.

| | Previous | This version |
|---|---|---|
| Topics | 104 | 104 |
| Action rows | 698 | 705 |

**2 topics added, 2 removed, 11 changed** (30 action rows edited or reworded).

## Topics added

- **CLI:weight** — weight — Sets the default weight for routes advertised by the neighbor or neighbor group  
  _CLI CONFIGURATION — BGP EVPN ADDRESS-FAMILY_ · 9 action rows
- **CLI:interface (EVPN)** — interface (EVPN) — Configures an interface (attachment circuit) under the VPLS/EVPN service  
  _CLI CONFIGURATION — L2-SERVICES EVPN_ · 11 action rows

## Topics removed

- **CLI:interface (VPLS/EVPN)** — interface (VPLS/EVPN) — Configures an interface (attachment circuit) under the VPLS/EVPN service  
  _CLI CONFIGURATION — L2-SERVICES EVPN_ · 13 action rows
- **CLI:mac-address-static (VPLS)** — mac-address-static (VPLS) — Configure a static MAC address  
  _CLI CONFIGURATION — L2-SERVICES VPLS_ · 10 action rows

## Topics changed

### CLI:af-l2vpn evpn — af-l2vpn evpn — Enables the L2VPN EVPN AFI/SAFI in neighbor or neighbor group

_CLI CONFIGURATION — BGP EVPN ADDRESS-FAMILY_ · 1 edited, 1 reworded

- **·** Under `af-l2vpn evpn`, type `?` to list the available options of the evpn SAFI sub-mode
    - _Expectation_: Pass: The evpn SAFI exposes exactly the documented options (7): allow-as-in, capability, inbound-soft-reconfiguration, maximum-prefix, policy, private-as, route-reflector-client Fail-on: An option is missing from `?`, or an undocumented op…
      → Pass: The evpn SAFI exposes exactly the documented options (8): allow-as-in, capability, inbound-soft-reconfiguration, maximum-prefix, policy, private-as, route-reflector-client, weight Fail-on: An option is missing from `?`, or an undocum…
- **~** Descend to the `configuration routing bgp vrf {neighbor|neighbor-group}` level and enter the `af-l2vpn evpn` container. It is a container node — it takes no value of its own and is not committed on its own. Configure its documented attribu…
  → Descend to the `configuration routing bgp vrf {neighbor|neighbor-group}` level and enter the `af-l2vpn evpn` container. It is a container node — it takes no value of its own and is not committed on its own. Configure its documented attribu…
    - _Expectation_: Pass: `af-l2vpn evpn` is entered as a container and its attributes (`allow-as-in`, `capability`, `inbound-soft-reconfiguration`, `maximum-prefix`, `policy`, `private-as`, `route-reflector-client`) are accepted and nested beneath it Pass: B…
      → Pass: `af-l2vpn evpn` is entered as a container and its attributes (`allow-as-in`, `capability`, `inbound-soft-reconfiguration`, `maximum-prefix`, `policy`, `private-as`, `route-reflector-client`, `weight`) are accepted and nested beneath …

### CLI:allow-as-in — allow-as-in — Accepts routes up to the specified number of instances of the local AS number in the AS-Path attribute

_CLI CONFIGURATION — BGP EVPN ADDRESS-FAMILY_ · 1 added, 1 edited, 2 reworded

- **·** Bring the parent feature up without configuring `allow-as-in`; observe the default behaviour
    - _Expectation_: Pass: Default behaviour matches doc: "disabled (no AS_PATH loops allowed)" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
      → Pass: Default behaviour matches doc: "no allow-as-in — disable the allow-as-in configuration" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
- **~** At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `allow-as-in <value>` and commit the candidate config
  → At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `allow-as-in <number>` and commit the candidate config
    - _Expectation_: Pass: `allow-as-in` is accepted and present in `show configuration` Pass: BGP AS_PATH loop check reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configured line is absent from `show configuratio…
      → Pass: `allow-as-in` is accepted and present in `show configuration` Pass: `allow-as-in` under af-l2vpn evpn reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configured line is absent from `show c…
- **~** Enter the command with its final mandatory token `<value>` omitted — type `allow-as-in` (instead of the complete `allow-as-in <value>`) and attempt to commit
  → Enter the command with its final mandatory token `<number>` omitted — type `allow-as-in` (instead of the complete `allow-as-in <number>`) and attempt to commit
    - _Expectation_: Pass: `allow-as-in` is rejected as incomplete — the mandatory `<value>` cannot be omitted Pass: the running configuration is unchanged Fail-on: The DUT accepts `allow-as-in` (silently supplies a value for the missing `<value>`, or commits …
      → Pass: `allow-as-in` is rejected as incomplete — the mandatory `<number>` cannot be omitted Pass: the running configuration is unchanged Fail-on: The DUT accepts `allow-as-in` (silently supplies a value for the missing `<number>`, or commit…
- **+** Issue `allow-as-in <number>` with values: (a) the documented boundary values (1, 10) — valid per '1-10'; (b) invalid values: 0 (below range); 11 (above range)

### CLI:capability — capability — Configures the capabilities to be advertised to the peer

_CLI CONFIGURATION — BGP EVPN ADDRESS-FAMILY_ · 3 added, 1 edited, 1 removed, 1 reworded

- **·** Bring the parent feature up without configuring `capability`; observe the default behaviour
    - _Expectation_: Pass: Default behaviour matches doc: "route-refresh advertised Pass: ORF off" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
      → Pass: Default behaviour matches doc: "no capability — disable advertising capabilities" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
- **~** At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `capability <value>` and commit the candidate config
  → At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `capability [dynamic {enable | disable}] [route-refresh {enable | disable}]` and commit the candidate config
    - _Expectation_: Pass: `capability` is accepted and present in `show configuration` Pass: BGP capability negotiation, RFC 5291 ORF, RFC 2918 Route Refresh reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configur…
      → Pass: `capability` is accepted and present in `show configuration` Pass: `capability` under af-l2vpn evpn reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configured line is absent from `show con…
- **+** Configure `capability` with each documented value (`dynamic`, `graceful-restart`): `capability [dynamic {enable | disable}] [route-refresh {enable | disable}]`, `capability [graceful-restart {enable | disable}] [orf {disable | both | <rece…
- **+** Issue `capability <orf>` with values: (a) a valid in-spec value (per 'both'); (b) invalid values: a value clearly outside the documented spec
- **+** Configure `capability` with one choice (e.g. `dynamic`); commit; then reconfigure with a different choice (dynamic | route-refresh | graceful-restart | disable | receive | send); commit
- **−** Enter the command with its final mandatory token `<value>` omitted — type `capability` (instead of the complete `capability <value>`) and attempt to commit

### CLI:inbound-soft-reconfiguration — inbound-soft-reconfiguration — Enables local storage of inbound routes and per neighbor soft reconfiguration

_CLI CONFIGURATION — BGP EVPN ADDRESS-FAMILY_ · 1 added, 1 edited, 1 reworded

- **·** Bring the parent feature up without configuring `inbound-soft-reconfiguration`; observe the default behaviour
    - _Expectation_: Pass: Default behaviour matches doc: "disabled (rely on Route Refresh)" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
      → Pass: Default behaviour matches doc: "no inbound-soft-reconfiguration — restore the default (disable)" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
- **~** At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `inbound-soft-reconfiguration` and commit the candidate config
  → At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `inbound-soft-reconfiguration [enable | disable]` and commit the candidate config
    - _Expectation_: Pass: `inbound-soft-reconfiguration` is accepted and present in `show configuration` Pass: BGP soft reconfiguration reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configured line is absent from…
      → Pass: `inbound-soft-reconfiguration` is accepted and present in `show configuration` Pass: `inbound-soft-reconfiguration` under af-l2vpn evpn reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the conf…
- **+** Configure `inbound-soft-reconfiguration` with one choice (e.g. `enable`); commit; then reconfigure with a different choice (enable | disable); commit

### CLI:maximum-prefix — maximum-prefix — Sets the maximum number of prefix accepted from this peer and configures the action to take if this maximum is exceeded

_CLI CONFIGURATION — BGP EVPN ADDRESS-FAMILY_ · 6 added, 1 edited, 2 removed

- **·** Bring the parent feature up without configuring `maximum-prefix`; observe the default behaviour
    - _Expectation_: Pass: Default behaviour matches doc: "no limit" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
      → Pass: Default behaviour matches doc: "no maximum-prefix — restore the default maximum" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
- **+** At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `<maximum-prefix> number <max> threshold <percent> action [warn | terminate]` and commit the candidate config
- **+** Issue `maximum-prefix <max>` with values: (a) the documented boundary values (0, 4294967295) — valid per '0- 4294967295'; (b) invalid values: -1 (below range); 4294967296 (above range). The documented default is `2097152`; with `maximum-pr…
- **+** Issue `maximum-prefix <percent>` with values: (a) the documented boundary values (1, 100) — valid per '1-100'; (b) invalid values: 0 (below range); 101 (above range). The documented default is `75`; with `maximum-prefix` omitted the value …
- **+** Read back the effective `max`; then explicitly set the documented default `maximum-prefix 2097152` and read back again
- **+** Read back the effective `percent`; then explicitly set the documented default `maximum-prefix 75` and read back again
- **+** Configure `maximum-prefix` with one choice (e.g. `warn`); commit; then reconfigure with a different choice (warn | terminate); commit
- **−** At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `<maximum-prefix> <value>` and commit the candidate config
- **−** Enter the command with its final mandatory token `<value>` omitted — type `<maximum-prefix>` (instead of the complete `<maximum-prefix> <value>`) and attempt to commit

### CLI:policy — policy — Sets an inbound or outbound policy on routes published or received from a neighbor

_CLI CONFIGURATION — BGP EVPN ADDRESS-FAMILY_ · 1 added, 1 edited, 3 reworded

- **·** Bring the parent feature up without configuring `policy`; observe the default behaviour
    - _Expectation_: Pass: Default behaviour matches doc: "no policy (all routes pass)" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
      → Pass: Default behaviour matches doc: "no policy — remove a specific or all inbound or Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
- **~** At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `policy <value>` and commit the candidate config
  → At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `policy {in | out} <policy-name>` and commit the candidate config
    - _Expectation_: Pass: `policy` is accepted and present in `show configuration` Pass: BGP routing-policy, EVPN route filtering reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configured line is absent from `show…
      → Pass: `policy` is accepted and present in `show configuration` Pass: `policy` under af-l2vpn evpn reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configured line is absent from `show configurati…
- **~** Enter the command with its final mandatory token `<value>` omitted — type `policy` (instead of the complete `policy <value>`) and attempt to commit
  → Enter the command with its final mandatory token `<policy-name>` omitted — type `policy {in | out}` (instead of the complete `policy {in | out} <policy-name>`) and attempt to commit
    - _Expectation_: Pass: `policy` is rejected as incomplete — the mandatory `<value>` cannot be omitted Pass: the running configuration is unchanged Fail-on: The DUT accepts `policy` (silently supplies a value for the missing `<value>`, or commits a partial …
      → Pass: `policy {in | out}` is rejected as incomplete — the mandatory `<policy-name>` cannot be omitted Pass: the running configuration is unchanged Fail-on: The DUT accepts `policy {in | out}` (silently supplies a value for the missing `<po…
- **~** Issue `no policy`; commit
  → Issue `no policy [in | out]`; commit
- **+** Issue `policy <policy-name>` with values: (a) a valid in-spec value (per 'Existing policy name'); (b) invalid values: a value clearly outside the documented spec

### CLI:private-as — private-as — Configures how to handle private AS numbers

_CLI CONFIGURATION — BGP EVPN ADDRESS-FAMILY_ · 1 added, 1 edited, 1 removed, 1 reworded

- **·** Bring the parent feature up without configuring `private-as`; observe the default behaviour
    - _Expectation_: Pass: Default behaviour matches doc: "disabled (private ASNs sent verbatim)" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
      → Pass: Default behaviour matches doc: "no private-as — restore the default (private AS numbers are Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
- **~** At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `private-as <value>` and commit the candidate config
  → At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `private-as [remove | leave]` and commit the candidate config
    - _Expectation_: Pass: `private-as` is accepted and present in `show configuration` Pass: BGP AS_PATH manipulation reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configured line is absent from `show configurati…
      → Pass: `private-as` is accepted and present in `show configuration` Pass: `private-as` under af-l2vpn evpn reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configured line is absent from `show con…
- **+** Configure `private-as` with one choice (e.g. `remove`); commit; then reconfigure with a different choice (remove | leave); commit
- **−** Enter the command with its final mandatory token `<value>` omitted — type `private-as` (instead of the complete `private-as <value>`) and attempt to commit

### CLI:route-reflector-client — route-reflector-client — Configures the neighbor or neighbor group as a route reflector client in the AS

_CLI CONFIGURATION — BGP EVPN ADDRESS-FAMILY_ · 1 added, 1 edited, 1 reworded

- **·** Bring the parent feature up without configuring `route-reflector-client`; observe the default behaviour
    - _Expectation_: Pass: Default behaviour matches doc: "disabled (neighbor is a regular iBGP peer)" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
      → Pass: Default behaviour matches doc: "no route-reflector-client — restore the default (disable)" Fail-on: Default differs from doc, or explicit config of the default value changes the configuration (non-idempotent)
- **~** At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `route-reflector-client` and commit the candidate config
  → At the `configuration routing bgp vrf neighbor af-l2vpn evpn` configuration level, configure `route-reflector-client [enable | disable]` and commit the candidate config
    - _Expectation_: Pass: `route-reflector-client` is accepted and present in `show configuration` Pass: BGP route reflection, RFC 4456 ORIGINATOR_ID / CLUSTER_LIST reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the c…
      → Pass: `route-reflector-client` is accepted and present in `show configuration` Pass: `route-reflector-client` under af-l2vpn evpn reads back via `show bgp neighbors <neighbor-ip> detail` Fail-on: Commit is rejected, or the configured line …
- **+** Configure `route-reflector-client` with one choice (e.g. `enable`); commit; then reconfigure with a different choice (enable | disable); commit

### CLI:auto-discovery — auto-discovery — Configures auto-discovery attributes

_CLI CONFIGURATION — L2-SERVICES EVPN_ · 2 edited

- **·** Descend to the `configuration l2-services evpn <evpn-name>` level and enter the `auto-discovery` container. It is a container node — it takes no value of its own and is not committed on its own. Configure its documented attributes in order…
    - _Expectation_: Pass: `auto-discovery` is entered as a container and its attributes (`export-rt`, `import-rt`) are accepted and nested beneath it Pass: BGP route-target reads back via `show configuration` Fail-on: `auto-discovery` is treated as a leaf (ac…
      → Pass: `auto-discovery` is entered as a container and its attributes (`export-rt`, `import-rt`) are accepted and nested beneath it Pass: BGP route-target reads back via `show evpn global [name <evpn-name>]` Fail-on: `auto-discovery` is trea…
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]
- **·** Issue `no auto-discovery`; commit
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]

### CLI:mac-aging-time — mac-aging-time — Configure the VPLS/EVPN MAC address table aging time

_CLI CONFIGURATION — L2-SERVICES EVPN_ · 5 edited

- **·** At the `configuration l2-services evpn <evpn-name>` configuration level, configure `mac-aging-time <seconds>` and commit the candidate config
    - _Expectation_: Pass: `mac-aging-time` is accepted and present in `show configuration` Pass: MAC table reads back via `show configuration` Fail-on: Commit is rejected, or the configured line is absent from `show configuration` after commit
      → Pass: `mac-aging-time` is accepted and present in `show configuration` Pass: MAC table reads back via `show evpn global [name <evpn-name>]` Fail-on: Commit is rejected, or the configured line is absent from `show configuration` after commit
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]
- **·** Enter the command with its final mandatory token `<seconds>` omitted — type `mac-aging-time` (instead of the complete `mac-aging-time <seconds>`) and attempt to commit
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]
- **·** Issue `mac-aging-time <seconds>` with values: (a) the documented boundary values (0, 40, 2400) — valid per '0, 40-2400'; (b) invalid values: -1 (below range); 1 (in the disallowed gap); 2401 (above range). The documented default is `300`; …
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]
- **·** Read back the effective `seconds`; then explicitly set the documented default `mac-aging-time 300` and read back again
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]
- **·** Issue `no mac-aging-time`; commit
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]

### CLI:mac-limit — mac-limit — Sets the maximum number of MAC addresses learned for the entire VPLS/EVPN service

_CLI CONFIGURATION — L2-SERVICES EVPN_ · 5 edited

- **·** At the `configuration l2-services evpn <evpn-name>` configuration level, configure `mac-limit <limit>` and commit the candidate config
    - _Expectation_: Pass: `mac-limit` is accepted and present in `show configuration` Pass: MAC table reads back via `show configuration` Fail-on: Commit is rejected, or the configured line is absent from `show configuration` after commit
      → Pass: `mac-limit` is accepted and present in `show configuration` Pass: MAC table reads back via `show evpn global [name <evpn-name>]` Fail-on: Commit is rejected, or the configured line is absent from `show configuration` after commit
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]
- **·** Enter the command with its final mandatory token `<limit>` omitted — type `mac-limit` (instead of the complete `mac-limit <limit>`) and attempt to commit
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]
- **·** Issue `mac-limit <limit>` with values: (a) the documented boundary values (1, 250000) — valid per '1-250000'; (b) invalid values: 0 (below range); 250001 (above range). The documented default is `65520`; with `mac-limit` omitted the value …
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]
- **·** Read back the effective `limit`; then explicitly set the documented default `mac-limit 65520` and read back again
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]
- **·** Issue `no mac-limit limit`; commit
    - _Monitor_: show configuration
      → show configuration, show evpn global [name <evpn-name>], show evpn mac-address-table [name <evpn-name>]

