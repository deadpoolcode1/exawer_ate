# No git bundle in this package

The generated suite is in `01_generated_suite/`, which is the same content.
What is missing here is the same content **as a branch of your repository**,
and it is missing for one reason:

**We still need a ticket ID (AUT-nnn / EM-nnnn).**

The branch cannot be pushed under its real name without one, so there is no
branch to bundle, and no TATE run recorded against a ticket. It has been the
first item on our "what we need from you" list since 24 August.

Give us the ticket ID and the branch and the TATE records follow the same day.
